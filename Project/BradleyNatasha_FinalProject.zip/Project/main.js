//Header
//what this page is about (phone product page)
const header = 'NEW PHONE X80';
console.log(header);

// H2/subhead
const h2Title = 'Features';
console.log(h2Title);

//What is the product
//what does it do
//use an array to store features;
const features = ['Water Proof', 'Touch Screen', 'Comes in variety of sizes'];

features.forEach(function (feature){
    console.log(feature);
});

//H3  why they need it
const h3Title = 'Gallery';
//photos will be here

//H4 where they can get the product
const  h4Title = 'Where to buy';

console.log(h4Title);